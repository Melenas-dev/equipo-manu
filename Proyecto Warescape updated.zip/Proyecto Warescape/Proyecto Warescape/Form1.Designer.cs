﻿
namespace Proyecto_Warescape
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ingreso = new System.Windows.Forms.Button();
            this.campo_usuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.campo_contra = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ingreso
            // 
            this.ingreso.Location = new System.Drawing.Point(153, 270);
            this.ingreso.Name = "ingreso";
            this.ingreso.Size = new System.Drawing.Size(75, 23);
            this.ingreso.TabIndex = 0;
            this.ingreso.Text = "Ingresar";
            this.ingreso.UseVisualStyleBackColor = true;
            this.ingreso.Click += new System.EventHandler(this.button1_Click);
            // 
            // campo_usuario
            // 
            this.campo_usuario.Location = new System.Drawing.Point(140, 146);
            this.campo_usuario.Name = "campo_usuario";
            this.campo_usuario.Size = new System.Drawing.Size(100, 20);
            this.campo_usuario.TabIndex = 1;
            this.campo_usuario.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(168, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Usuario";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Contraseña";
            // 
            // campo_contra
            // 
            this.campo_contra.Location = new System.Drawing.Point(140, 223);
            this.campo_contra.Name = "campo_contra";
            this.campo_contra.Size = new System.Drawing.Size(100, 20);
            this.campo_contra.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 450);
            this.Controls.Add(this.campo_contra);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.campo_usuario);
            this.Controls.Add(this.ingreso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ingreso;
        private System.Windows.Forms.TextBox campo_usuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox campo_contra;
    }
}

